# RakhA-BoT R3c1n9
BOT WHATSAPP TERMUX BY : RAKHA MHDZ

### Alat dan Bahan
Siapin alat dan bahannya.
```bash
> niat
> 2 handphone (1 buat jalanin sc, 1 buat scan qr)
> internet yang memadai, kalo lu gapunya kuota pake kuota kemendikbud ae
> aplikasi whatsapp
> aplikasi termux
> kopi
```

### Cara Installnya
Sebelum lu jalanin sc nya install dulu lah.
```bash
> kalo lu belum punya apk termux, download di playstore
> masuk ke apk termux lalu ketik dibawah ini!
> git clone https://github.com/Rakha21/bot-hp.git
> cd bot-hp
> bash install.sh
> node index.js
> Tinggal scan qr dah
```

## Features

| st4rz BOT       |                Feature           |
| :-----------: | :--------------------------------: |
|       ✅       | Sticker Creator                  |
|       ✅       | Magernulis                       |
|       ✅       | Pantun                           |
|       ✅       | Youtube Downloader               |
|       ✅       | Quotes                           |
|       ✅       | Anime                            |
|       ✅       | Suara Google                     |
|       ✅       | Quran                            |
|       ✅       | Youtube MP3 Downloader           |
|       ✅       | Intagram Downloader              |
|       ✅       | Twitter Downloader               |
|       ✅       | Facebook Downloader              |
|       ✅       | Wikipedia                        |
|       ✅       | Say                              |
|       ✅       | Info                             |
|       ✅       | Donate                           |

## Special Thanks to
*Tuhan Yang Maha Esa
*Hp Kentang : Black Shark 2
*laptop kentang : ROG -G Series Limitid Edition

### Donate
*GOPAY : 082138746029
*DANA : 082138746029
*PULSA : 082138746029
